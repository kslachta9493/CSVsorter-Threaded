#ifndef SORTER_H
#define SORTER_H

int loadAndSort(int argc, char* argv[], int coltosorton, char* userinputdirectory, char* name, char* useroutputdirectory);

typedef struct csv {
	char** filedata;
} CSV;

typedef struct coltypes {
	int type;
} COLTYPES;


//Suggestion: prototype a mergesort function


#endif
