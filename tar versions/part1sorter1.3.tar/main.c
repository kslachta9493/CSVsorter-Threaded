
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sorter.h"
#include "builder.h"
#include <dirent.h>

int childPIDS[255];
char *childCSVS[255];
char *childCSVname[255];
int childCSVPIDS[255];
int totalcsv = 0;
char *userinputdirectory = NULL;
char *useroutputdirectory = NULL;


int main (int argc, char* argv[])
{

	int parentpid = getpid();
	int freeinput = 0;
	int freeoutput = 0;

	printf("Initial PID: %d\n", parentpid);
	printf("Child PIDS: ");
	fflush(stdout);


	int finalpidcount = 0;
	int i = 0;
	int coltosorton = validflags(argc, argv);
	if ("1")
	{
		//invalid flags output error
	}
	if (userinputdirectory == NULL)
	{
		userinputdirectory = (char*) malloc (2*sizeof(char));
		userinputdirectory[0] = '.';
		userinputdirectory[1] = '\0';
		freeinput = 1;
	} else {
		FILE* fp;
		fp = fopen(userinputdirectory, "r");
	
		if (fp == NULL)
		{
			printf("\nInvalid input directory %s\n", userinputdirectory);
			exit(-1);
		}
		close(fp);
	}
	if (useroutputdirectory == NULL)
	{
		/*
		useroutputdirectory = (char*) malloc (2*sizeof(char));
		useroutputdirectory[0] = '.';
		useroutputdirectory[1] = '\0';
		*/
		useroutputdirectory = strdup(userinputdirectory);
		freeoutput = 1;
	} else
	{
		FILE* fp;
		fp = fopen(userinputdirectory, "r");
	
		if (fp == NULL)
		{
			printf("\nInvalid output directory %s\n", useroutputdirectory);
			exit(-1);
		}
		close(fp);
	}

	for (i = 0; i < 255; i++)
	{
		childPIDS[i] = 0;
		childCSVPIDS[i] = 0;
		childCSVname[i] = " ";
	}
	//populateDIR(userinputdirectory);
	
	pid_t firstfork = fork();

	if (firstfork == 0)
	{
		int status = 0;
		int childcount = 0;
		printf(" %d", getpid());
		fflush(stdout);
		int totaldirs = populateDIR(userinputdirectory);

		int ischild = -1;
		
		for (i = 0; i < totalcsv; i++)
		{
			//printf("%s\n", childCSVS[i]);
			childCSVPIDS[i] = fork();
			if (childCSVPIDS[i] == 0)
			{
				ischild = i;
				printf(", %d", getpid());
				//printf("%d + %d\n", i, getpid());
				break;
			} else
			{
				//printf("MADE CHILD\n");
				ischild = -1;
			}
		}
		childcount += totalcsv;
		if (ischild >= 0)
		{
			loadAndSort(argc, argv, coltosorton, childCSVS[ischild], childCSVname[ischild], useroutputdirectory);

		} else {
		
			for (i = 0; i < totaldirs; i++)
			{
				status = 0;
				int test = waitpid(childPIDS[i], &status, WUNTRACED);
				if (test == 1)
					printf("WAIT FAILED DIR\n");
				int returned = WEXITSTATUS(status);

				childcount = childcount + returned;
			}
			childcount += totaldirs;
			
			for (i = 0; i < totalcsv; i++)
			{
				int test = waitpid(childCSVPIDS[i], &status, WUNTRACED);
				if (test == -1)
					printf("WAIT FAILED CSV\n");
			}
			
			return childcount;
		}
	} else
	{
		//printf("FIRSTFORK %d\n", firstfork);
		int test = waitpid(firstfork, &finalpidcount, WUNTRACED);
		if (test == -1)
			printf("WAIT FAILED!!!!!!!!\n");
		int returned = WEXITSTATUS(finalpidcount);
		printf("\nTotal Process: %d\n", returned + 2);
	}
	if (freeinput)
		free(userinputdirectory);
	
	if (freeoutput)
		free(useroutputdirectory);

	return 0;
}

int validflags(int argc, char* argv[])
{
	int i = 0;
	int acceptedargs = -1;
	for (i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "-c") == 0)
		{
			if (argv[i + 1] != NULL)
			{
				acceptedargs = 0;
			}
		}
		if (strcmp(argv[i], "-d") == 0)
		{
			userinputdirectory = strdup(argv[i + 1]);
		}
		if (strcmp(argv[i], "-o") == 0)
		{
			useroutputdirectory = strdup(argv[i + 1]);
		}
	}
	return acceptedargs;
}

int populateDIR(char *name)
{
    	DIR *dir;
    	struct dirent *entry;
	int totalchildren = 0;

   	if (!(dir = opendir(name)))
        	return 0;

	while ((entry = readdir(dir)) != NULL) 
	{
		if (entry->d_type == DT_DIR) {
			if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
			{
			} else
			{
				//fork new process for directory
				childPIDS[totalchildren] = fork();
				if (childPIDS[totalchildren] == 0)
				{
		    			char *path = (char*) malloc ((strlen(name) + strlen(entry->d_name) + 2) * sizeof(char));
					strcpy(path, name);
					strcat(path, "/");
					strcat(path, entry->d_name);
					totalchildren = 0;
					totalcsv = 0;
					int i = 0;
					for (i = 0; i < 255; i++)
					{
						childCSVS[i] = " ";
						childCSVname[i] = " ";
						childPIDS[i] = 0;
					}
					printf(", %d", getpid());	
					fflush(stdout);
					int val = populateDIR(path);
					//free(path);
					return ;
				} else
				{
					totalchildren++;
				}
			}
        	} else {
			if (strstr(entry->d_name, ".csv"))
			{
				if (!strstr(entry->d_name, "-sorted-"))
				{
					childCSVS[totalcsv] = strdup(name);
					childCSVname[totalcsv] = strdup(entry->d_name);
					totalcsv++;

					fflush(stdout);
				}
			}
       		}
    	}
	closedir(dir);
	return totalchildren;
}

