#ifndef SORTER_H
#define SORTER_H

typedef struct csv {
	char** filedata;
} CSV;

typedef struct coltypes {
	int type;
} COLTYPES;


//Suggestion: prototype a mergesort function


#endif
